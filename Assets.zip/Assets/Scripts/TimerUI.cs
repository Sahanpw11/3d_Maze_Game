using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
public class TimerUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI TimerText;



    private void Update()
    {
        TimerText.text = Mathf.Ceil(GameHandler.Instance.UpdateTimerUI()).ToString("F2") + "s";
    }
    private void Show()
    {
        gameObject.SetActive(true);
    }

    private void Hide()
    {
        gameObject.SetActive(false);
    }

}