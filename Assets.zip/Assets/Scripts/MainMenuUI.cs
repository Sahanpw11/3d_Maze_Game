using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuUI : MonoBehaviour
{
    // Reference to the play button UI element
    [SerializeField] private Button playButton;
    // Reference to the quit button UI element
    [SerializeField] private Button quitButton;

    // Called when the script instance is being awakened
    private void Awake()
    {
        // Add a listener to the play button to load the game scene when clicked
        playButton.onClick.AddListener(() =>
        {
            Loader.Load(Loader.Scene.GameScene);
        });
        // Add a listener to the quit button to quit the application when clicked
        quitButton.onClick.AddListener(() =>
        {
            Application.Quit();
        });
    }
}
