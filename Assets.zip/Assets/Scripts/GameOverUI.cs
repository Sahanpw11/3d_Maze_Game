using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameOverUI : MonoBehaviour
{
    // Reference to the TimerText UI element using TextMeshProUGUI
    [SerializeField] private TextMeshProUGUI TimerText;
    // Reference to the Restart button UI element
    [SerializeField] private Button RestartButton;
    // Reference to the Quit button UI element
    [SerializeField] private Button QuitButton;

    // Called when the script instance is being loaded
    private void Start()
    {
        // Subscribe to the GameHandler's OnStateChanged event
        GameHandler.Instance.OnStateChanged += GameHandler_OnStateChanged;
        // Initially hide the game over UI
        Hide();
    }

    // Event handler for GameHandler's OnStateChanged event
    private void GameHandler_OnStateChanged(object sender, System.EventArgs e)
    {
        // Show the game over UI if the game is over, otherwise hide it
        if (GameHandler.Instance.IsGameOver())
        {
            Show();
        }
        else
        {
            Hide();
        }
    }

    // Called when the script instance is being awakened
    public void Awake()
    {
        // Add a listener to the Restart button to load the game scene when clicked
        RestartButton.onClick.AddListener(() =>
        {
            Loader.Load(Loader.Scene.GameScene);
        });

        // Add a listener to the Quit button to quit the application when clicked
        QuitButton.onClick.AddListener(() =>
        {
            Application.Quit();
        });
    }

    // Update is called once per frame
    private void Update()
    {
        // Update the TimerText with the current game playing time, rounded up and formatted
        TimerText.text = Mathf.Ceil(GameHandler.Instance.UpdateTimerUI()).ToString("F2") + "s";
    }

    // Method to show the game over UI
    private void Show()
    {
        gameObject.SetActive(true);
    }

    // Method to hide the game over UI
    private void Hide()
    {
        gameObject.SetActive(false);
    }
}
