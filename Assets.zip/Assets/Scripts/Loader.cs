using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Loader
{
    // Enumeration to represent different scenes
    public enum Scene
    {
        GameScene,
        MainMenuScene,
        LoadingScene
    }

    // Variable to store the target scene to load
    private static Scene targetScene;

    // Method to load the specified target scene
    public static void Load(Scene targetScene)
    {
        // Store the target scene
        Loader.targetScene = targetScene;
        // Load the loading scene to show a loading screen
        SceneManager.LoadScene(Scene.LoadingScene.ToString());
    }

    // Callback method to be called after the loading screen is shown
    public static void LoaderCallback()
    {
        // Load the target scene
        SceneManager.LoadScene(targetScene.ToString());
    }
}
