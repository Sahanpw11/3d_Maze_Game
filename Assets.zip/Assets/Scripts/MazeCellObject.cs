using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MazeCellObject : MonoBehaviour
{
    // References to the wall game objects for each side of the maze cell
    [SerializeField] private GameObject topWall;
    [SerializeField] private GameObject bottomWall;
    [SerializeField] private GameObject leftWall;
    [SerializeField] private GameObject rightWall;

    // Method to initialize the maze cell with wall visibility
    public void Init(bool top, bool bottom, bool left, bool right)
    {
        // Set the visibility of each wall based on the provided parameters
        topWall.SetActive(top);
        bottomWall.SetActive(bottom);
        leftWall.SetActive(left);
        rightWall.SetActive(right);
    }
}
