using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MazeGenerator : MonoBehaviour
{
    [Range(5, 500)]
    public int mazeWidth = 5, mazeHeight = 5; // Dimensions of the maze
    public int startX = 0, startY = 0; // Starting point of the maze
    public MazeCell[,] maze; // 2D array of cells

    Vector2Int currentCell; // Current cell being visited

    public Vector2Int characterSpawnPoint;
    public Vector2Int exitPoint;

    public MazeCell[,] GetMaze()
    {
        // Initialize the maze array
        maze = new MazeCell[mazeWidth, mazeHeight];
        // Loop through each cell and initialize it
        for (int x = 0; x < mazeWidth; x++)
        {
            for (int y = 0; y < mazeHeight; y++)
            {
                maze[x, y] = new MazeCell(x, y);
            }
        }

        // Start carving path from the start point
        CarvePath(startX, startY);

        // Set the exit point at the upper right corner
        exitPoint = SetExitPoint();

        // Set the character spawn point at the bottom left corner
        characterSpawnPoint = new Vector2Int(0, 0);
        maze[0, 0].visited = true; // Mark the spawn point as visited to avoid revisiting

        return maze;
    }

    // List of possible directions
    List<Direction> directions = new List<Direction>(){
        Direction.Up,
        Direction.Down,
        Direction.Left,
        Direction.Right
    };

    // Get random order of directions
    List<Direction> GetRandomDirections()
    {
        // Make a copy of the directions list
        List<Direction> dir = new List<Direction>(directions);

        // Make a directions list with random order
        List<Direction> rndDir = new List<Direction>();
        while (dir.Count > 0)
        {
            int rnd = Random.Range(0, dir.Count);  // Get a random index from list
            rndDir.Add(dir[rnd]);                  // Add the direction at that index to rndDir list
            dir.RemoveAt(rnd);
        }
        // What we get is a list of directions in random order
        return rndDir;
    }

    // Check if a cell is valid
    bool IsCellValid(int x, int y)
    {
        if (x < 0 || y < 0 || x >= mazeWidth || y >= mazeHeight || maze[x, y].visited) return false;
        return true;
    }

    // Check neighbours of the current cell
    Vector2Int CheckNeighbours()
    {
        List<Direction> rndDir = GetRandomDirections();
        for (int i = 0; i < rndDir.Count; i++)
        {
            // Set neighbour cell based on the direction
            Vector2Int neighbour = currentCell;

            // Modify the neighbour cell based on the direction
            switch (rndDir[i])
            {
                case Direction.Up:
                    neighbour.y++;
                    break;
                case Direction.Down:
                    neighbour.y--;
                    break;
                case Direction.Left:
                    neighbour.x--;
                    break;
                case Direction.Right:
                    neighbour.x++;
                    break;
            }
            // If the neighbour cell is valid, return the neighbour cell
            if (IsCellValid(neighbour.x, neighbour.y))
                return neighbour;
        }
        // If no valid neighbour cell is found, return the current cell
        return currentCell;
    }

    // Break walls between cells
    void BreakWalls(Vector2Int primaryCell, Vector2Int secondaryCell)
    {
        // Break the wall between the primary and secondary cells
        if (primaryCell.x > secondaryCell.x)
        {
            maze[primaryCell.x, primaryCell.y].leftWall = false;
        }
        else if (primaryCell.x < secondaryCell.x)
        {
            maze[secondaryCell.x, secondaryCell.y].leftWall = false;
        }
        else if (primaryCell.y < secondaryCell.y)
        {
            maze[primaryCell.x, primaryCell.y].topWall = false;
        }
        else if (primaryCell.y > secondaryCell.y)
        {
            maze[secondaryCell.x, secondaryCell.y].topWall = false;
        }
    }

    // Carve path through the maze
    void CarvePath(int x, int y)
    {
        // Perform a quick check to make sure the start cell is within the maze
        // If not, set the start cell to 0,0
        if (x < 0 || y < 0 || x >= mazeWidth || y >= mazeHeight)
        {
            x = 0;
            y = 0;
            Debug.LogWarning("Start point is outside the maze. Resetting to 0,0");
        }
        currentCell = new Vector2Int(x, y);

        // A list to keep track of our current path
        List<Vector2Int> path = new List<Vector2Int>();

        // Loop until a dead end is reached
        bool deadEnd = false;
        while (!deadEnd)
        {
            // Get a neighbour cell
            Vector2Int nextCell = CheckNeighbours();

            // If the neighbour cell is the same as the current cell, it means we have reached a dead end
            if (nextCell == currentCell)
            {
                for (int i = path.Count - 1; i >= 0; i--)
                {
                    currentCell = path[i];                         // Set the current cell to the last cell in the path
                    path.RemoveAt(i);                              // Remove the last cell from the path
                    nextCell = CheckNeighbours();                  // Check for neighbours

                    // If a neighbour cell is found, break the loop
                    if (nextCell != currentCell) break;
                }
                // If no neighbour cell is found, it means we have reached a dead end
                if (nextCell == currentCell) deadEnd = true;
            }
            else
            {
                BreakWalls(currentCell, nextCell);                       // Set wall flags on these cells
                maze[currentCell.x, currentCell.y].visited = true;       // Set cell to visited before moving on
                currentCell = nextCell;                                  // Move to the neighbour cell
                path.Add(currentCell);                                   // Add the current cell to the path
            }
        }
    }

    // Set the exit point of the maze
    public Vector2Int SetExitPoint()
    {
        Vector2Int exit = new Vector2Int(mazeWidth - 1, mazeHeight - 1);

        // Open the appropriate wall to create an opening at the exit point
        if (exit.x == mazeWidth - 1)
        {
            maze[exit.x, exit.y].leftWall = false;
        }
        if (exit.y == mazeHeight - 1)
        {
            maze[exit.x, exit.y].topWall = false;
        }

        maze[exit.x, exit.y].isExit = true;
        maze[exit.x, exit.y].navigable = true;

        return exit;
    }
}

public enum Direction
{
    Up,
    Down,
    Left,
    Right
}

public class MazeCell
{
    public Vector2Int position; // Position of the cell
    public int x { get { return position.x; } } // X coordinate of the cell
    public int y { get { return position.y; } } // Y coordinate of the cell
    public bool visited; // Has the cell been visited?
    public bool leftWall, topWall; // Walls of the cell
    public bool isExit; // Is this cell the exit?
    public bool navigable; // Is this cell navigable?

    // Constructor to initialize a maze cell
    public MazeCell(int x, int y)
    {
        position = new Vector2Int(x, y);
        visited = false;
        leftWall = true;
        topWall = true;
        isExit = false;
        navigable = true; // Set navigable to true by default
    }
}

