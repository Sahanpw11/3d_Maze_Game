using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f; // Movement speed of the player
    [SerializeField] private GameInput gameInput; // Reference to the GameInput script

    private bool isWalking; // Flag to indicate if the player is walking
    private Vector2Int exitPoint = new Vector2Int(47, 47); // Exit point coordinates

    private void Update()
    {
        // Check if the game is not in the playing state
        if (!GameHandler.Instance.IsGamePlaying())
        {
            return;
        }

        // Get movement input from the GameInput script
        Vector3 moveDir = gameInput.GetMovementVectorNormalized();

        // If there's movement input
        if (moveDir != Vector3.zero)
        {
            // Check if the player can move in the desired direction (not blocked by obstacles)
            bool canMove = !Physics.Raycast(transform.position, moveDir, 0.5f);
            if (canMove)
            {
                // Move the player
                transform.position += moveDir * moveSpeed * Time.deltaTime;
            }

            // Rotate the player to face the movement direction smoothly
            transform.forward = Vector3.Slerp(transform.forward, moveDir, Time.deltaTime * 10f);
        }

        // Update the walking flag based on movement input
        isWalking = moveDir != Vector3.zero;

        // Check if the player has reached the exit point
        Vector2Int playerPosition = new Vector2Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.z));
        if (playerPosition == exitPoint)
        {
            // End the game if the player reaches the exit point
            GameHandler.Instance.EndGame();
        }
    }

    // Method to check if the player is walking
    public bool IsWalking()
    {
        return isWalking;
    }
}
