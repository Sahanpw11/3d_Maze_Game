using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    private const string IS_WALKING = "IsWalking"; // Animator parameter name for walking animation

    [SerializeField] private Player player; // Reference to the Player script controlling player movement
    private Animator animator; // Reference to the Animator component

    private void Awake()
    {
        animator = GetComponent<Animator>(); // Get the Animator component attached to the same GameObject
    }

    private void Update()
    {
        // Update the "IsWalking" parameter in the animator based on player's walking state
        animator.SetBool(IS_WALKING, player.IsWalking());
    }
}
