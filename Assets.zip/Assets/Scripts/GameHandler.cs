using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // Required for using UI elements

public class GameHandler : MonoBehaviour
{
    // Singleton instance of the GameHandler
    public static GameHandler Instance { get; private set; }

    // Event triggered when the game state changes
    public event EventHandler OnStateChanged;

    // Enum representing different game states
    private enum State
    {
        WaitingToStart,
        CountDowntoStart,
        GamePlaying,
        GameOver,
    }

    // Current state of the game
    private State state;
    // Timer for waiting to start
    private float waitingToStartTimer = 1f;
    // Timer for countdown before the game starts
    private float countdownToStartTimer = 3f;
    // Timer for tracking game playing duration
    private float gamePlayingTimer;

    // Reference to the UI Text element displaying the timer
    [SerializeField] private Text timerText;

    // Awake is called when the script instance is being loaded
    private void Awake()
    {
        // Initialize the singleton instance
        Instance = this;
        // Set initial game state to waiting to start
        state = State.WaitingToStart;
    }

    // Update is called once per frame
    private void Update()
    {
        // Switch statement handling different game states
        switch (state)
        {
            case State.WaitingToStart:
                // Decrement the waiting timer
                waitingToStartTimer -= Time.deltaTime;
                // Transition to countdown state when timer reaches zero
                if (waitingToStartTimer <= 0)
                {
                    state = State.CountDowntoStart;
                    OnStateChanged?.Invoke(this, EventArgs.Empty);
                }
                break;
            case State.CountDowntoStart:
                // Decrement the countdown timer
                countdownToStartTimer -= Time.deltaTime;
                // Transition to game playing state when timer reaches zero
                if (countdownToStartTimer <= 0)
                {
                    state = State.GamePlaying;
                    gamePlayingTimer = 0f; // Reset the game playing timer
                    OnStateChanged?.Invoke(this, EventArgs.Empty);
                }
                break;
            case State.GamePlaying:
                // Increment the game playing timer
                gamePlayingTimer += Time.deltaTime;
                // Update the timer UI
                UpdateTimerUI();
                break;
            case State.GameOver:
                // Logic for when the game is over (if any)
                break;
        }

        // Log the current state for debugging purposes
        Debug.Log(state);
    }

    // Method to check if the game is currently playing
    public bool IsGamePlaying()
    {
        return state == State.GamePlaying;
    }

    // Method to end the game and transition to the game over state
    public void EndGame()
    {
        state = State.GameOver;
        OnStateChanged?.Invoke(this, EventArgs.Empty);
        Debug.Log("Game Over! Player reached the exit.");
        Debug.Log("Time taken: " + gamePlayingTimer.ToString("F2") + " seconds");
    }

    // Method to check if the countdown to start is active
    public bool IsCountdowntoStartActive()
    {
        return state == State.CountDowntoStart;
    }

    // Method to get the remaining countdown timer value
    public float GetCountdownToStartTimer()
    {
        return countdownToStartTimer;
    }

    // Method to check if the game is over
    public bool IsGameOver()
    {
        return state == State.GameOver;
    }

    // Method to update the timer UI text
    public float UpdateTimerUI()
    {
        // Check if the timerText is not null
        if (timerText != null)
        {
            // Update the UI text with the current game playing timer
            timerText.text = "Time: " + gamePlayingTimer.ToString("F2") + "s";
        }
        // Return the current game playing timer
        return gamePlayingTimer;
    }
}
