using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameStartCountdownUI : MonoBehaviour
{
    // Reference to the countdown text UI element using TextMeshProUGUI
    [SerializeField] private TextMeshProUGUI countdownText;

    // Called when the script instance is being loaded
    private void Start()
    {
        // Subscribe to the GameHandler's OnStateChanged event
        GameHandler.Instance.OnStateChanged += GameHandler_OnStateChanged;
        // Initially hide the countdown UI
        Hide();
    }

    // Event handler for GameHandler's OnStateChanged event
    private void GameHandler_OnStateChanged(object sender, System.EventArgs e)
    {
        // Show the countdown UI if the countdown to start is active, otherwise hide it
        if (GameHandler.Instance.IsCountdowntoStartActive())
        {
            Show();
        }
        else
        {
            Hide();
        }
    }

    // Update is called once per frame
    private void Update()
    {
        // Update the countdown text with the remaining countdown timer, rounded up
        countdownText.text = Mathf.Ceil(GameHandler.Instance.GetCountdownToStartTimer()).ToString();
    }

    // Method to show the countdown UI
    private void Show()
    {
        gameObject.SetActive(true);
    }

    // Method to hide the countdown UI
    private void Hide()
    {
        gameObject.SetActive(false);
    }
}
